﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,_(j,k),l,[m,n,o,p],q,_(r,s,t,u,v,w,x,_(),y,_(z,A,B,C,D,_(E,F,G,H),I,null,J,K,L,K,M,N,O,null,P,Q,R,S,T,U,V,Q),W,_(),X,_(),Y,_(Z,[])),ba,_(),bb,_());}; 
var b="url",c="游艇评价展示页面（待补充）.html",d="generationDate",e=new Date(1527136795255),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="sketchKeys",j="",k="s0",l="variables",m="OnLoadVariable",n="Menu",o="NewVariable",p="NewVariable1",q="page",r="packageId",s="20059b7bbdf9446f91916ed103530ca5",t="type",u="Axure:Page",v="name",w="游艇评价展示页面（待补充）",x="notes",y="style",z="baseStyle",A="627587b6038d43cca051c114ac41ad32",B="pageAlignment",C="center",D="fill",E="fillType",F="solid",G="color",H=0xFFF6F7F9,I="image",J="imageHorizontalAlignment",K="near",L="imageVerticalAlignment",M="imageRepeat",N="auto",O="favicon",P="sketchFactor",Q="0",R="colorStyle",S="appliedColor",T="fontName",U="Applied Font",V="borderWidth",W="adaptiveStyles",X="interactionMap",Y="diagram",Z="objects",ba="masters",bb="objectPaths";
return _creator();
})());